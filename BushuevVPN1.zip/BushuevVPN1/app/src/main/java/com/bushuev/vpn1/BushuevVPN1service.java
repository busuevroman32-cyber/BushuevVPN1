package com.bushuev.vpn1;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;


class BushuevVpnService extends VpnService {

    public static final String ACTION_CONNECT = "com.bushuev.vpnfree.CONNECT";
    public static final String ACTION_DISCONNECT = "com.bushuev.vpnfree.DISCONNECT";
    public static final String EXTRA_HOST = "host";
    public static final String EXTRA_PORT = "port";
    private static final String CHANNEL_ID = "bushuev_vpn";
    private static final String TAG = "BushuevVpn";

    private ParcelFileDescriptor vpnInterface;
    private Thread reader;
    private volatile boolean running = false;
    private String proxyHost = "127.0.0.1";
    private int proxyPort = 1080;

    private final Map<String, Socket> tcpSockets = new ConcurrentHashMap<>();
    private final Map<Integer, DatagramSocket> udpSockets = new ConcurrentHashMap<>();
    private FileOutputStream out;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if (ACTION_DISCONNECT.equals(action)) {
                stopVpn();
                return START_NOT_STICKY;
            }
            if (ACTION_CONNECT.equals(action)) {
                proxyHost = intent.getStringExtra(EXTRA_HOST);
                proxyPort = intent.getIntExtra(EXTRA_PORT, 1080);
                if (proxyHost == null || proxyHost.isEmpty()) proxyHost = "127.0.0.1";
                startVpn();
            }
        }
        return START_STICKY;
    }

    private void startVpn() {
        if (running) return;

        Builder builder = new Builder();
        builder.setSession("BushuevVPNFREE");
        builder.addAddress("10.8.0.2", 32);
        builder.addRoute("0.0.0.0", 0);
        builder.addDnsServer("1.1.1.1");
        builder.addDnsServer("8.8.8.8");
        builder.setMtu(1500);
        try {
            builder.addDisallowedApplication(getPackageName());
        } catch (Exception ignored) {}

        try {
            vpnInterface = builder.establish();
        } catch (Exception e) {
            Log.e(TAG, "establish failed", e);
            vpnInterface = null;
            return;
        }
        if (vpnInterface == null) return;

        out = new FileOutputStream(vpnInterface.getFileDescriptor());
        running = true;
        startForeground(1, buildNotification());

        reader = new Thread(new Runnable() {
				@Override
				public void run() {
					readLoop();
				}
			}, "bushuev-tun-reader");
        reader.start();
    }

    private void readLoop() {
        FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
        byte[] packet = new byte[32767];
        try {
            while (running) {
                int len = in.read(packet);
                if (len <= 0) break;
                if (len < 20) continue;
                int version = (packet[0] >> 4) & 0xF;
                if (version != 4) continue;
                handleIpv4(packet, len);
            }
        } catch (Exception e) {
            Log.e(TAG, "read loop", e);
        } finally {
            try { in.close(); } catch (Exception ignored) {}
        }
    }

    private void handleIpv4(byte[] p, int len) {
        int ihl = (p[0] & 0xF) * 4;
        int protocol = p[9] & 0xFF;
        byte[] srcIp = new byte[4];
        byte[] dstIp = new byte[4];
        System.arraycopy(p, 12, srcIp, 0, 4);
        System.arraycopy(p, 16, dstIp, 0, 4);
        int srcPort = ((p[ihl] & 0xFF) << 8) | (p[ihl + 1] & 0xFF);
        int dstPort = ((p[ihl + 2] & 0xFF) << 8) | (p[ihl + 3] & 0xFF);

        if (protocol == 6) {
            handleTcp(p, len, ihl, srcIp, dstIp, srcPort, dstPort);
        } else if (protocol == 17) {
            handleUdp(p, len, ihl, srcIp, dstIp, srcPort, dstPort);
        }
    }

    private void handleTcp(byte[] p, int len, int ihl, byte[] srcIp,
                           byte[] dstIp, int srcPort, int dstPort) {
        int tcpOff = ihl;
        int flags = p[tcpOff + 13] & 0xFF;
        boolean syn = (flags & 0x02) != 0;
        String key = ipToString(srcIp) + ":" + srcPort + "-" +
			ipToString(dstIp) + ":" + dstPort;

        if (syn) {
            final String fKey = key;
            final byte[] fDstIp = dstIp;
            final int fDstPort = dstPort;
            new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							Socket s = new Socket();
							protect(s);
							s.connect(new InetSocketAddress(proxyHost, proxyPort), 15000);
							s.setSoTimeout(30000);
							socks5Connect(s, fDstIp, fDstPort);
							tcpSockets.put(fKey, s);
							pumpTcp(fKey, s);
						} catch (Exception e) {
							Log.e(TAG, "tcp connect", e);
						}
					}
				}, "bushuev-tcp-" + key).start();
        } else {
            Socket s = tcpSockets.get(key);
            if (s != null) {
                try {
                    int payloadLen = len - ihl - ((p[ihl + 12] & 0xFF) >> 4) * 4;
                    if (payloadLen > 0) {
                        OutputStream os = s.getOutputStream();
                        os.write(p, ihl + ((p[ihl + 12] & 0xFF) >> 4) * 4, payloadLen);
                        os.flush();
                    }
                } catch (Exception e) {
                    tcpSockets.remove(key);
                    try { s.close(); } catch (Exception ignored) {}
                }
            }
        }
    }

    private void pumpTcp(final String key, final Socket s) {
        try {
            InputStream is = s.getInputStream();
            byte[] buf = new byte[8192];
            while (running) {
                int n = is.read(buf);
                if (n <= 0) break;
                writeTcpToTun(key, s, buf, n);
            }
        } catch (Exception e) {
            Log.e(TAG, "pumpTcp", e);
        } finally {
            tcpSockets.remove(key);
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    private synchronized void writeTcpToTun(String key, Socket s, byte[] data, int n) {
        try {
            String[] parts = key.split("-");
            String[] src = parts[0].split(":");
            String[] dst = parts[1].split(":");
            byte[] srcIp = ipFromString(src[0]);
            byte[] dstIp = ipFromString(dst[0]);
            int srcPort = Integer.parseInt(src[1]);
            int dstPort = Integer.parseInt(dst[1]);

            byte[] tcp = new byte[20 + n];
            tcp[0] = (byte) (srcPort >> 8);
            tcp[1] = (byte) srcPort;
            tcp[2] = (byte) (dstPort >> 8);
            tcp[3] = (byte) dstPort;
            tcp[12] = (byte) 0x50;
            tcp[13] = (byte) 0x18;
            System.arraycopy(data, 0, tcp, 20, n);

            byte[] ip = new byte[20 + tcp.length];
            ip[0] = 0x45;
            ip[1] = 0;
            ip[2] = (byte) ((ip.length) >> 8);
            ip[3] = (byte) ip.length;
            ip[8] = 64;
            ip[9] = 6;
            System.arraycopy(dstIp, 0, ip, 12, 4);
            System.arraycopy(srcIp, 0, ip, 16, 4);
            System.arraycopy(tcp, 0, ip, 20, tcp.length);
            writeIp(ip);
        } catch (Exception e) {
            Log.e(TAG, "writeTcpToTun", e);
        }
    }

    private void handleUdp(byte[] p, int len, int ihl, byte[] srcIp,
                           byte[] dstIp, int srcPort, int dstPort) {
        int payloadOff = ihl + 8;
        int payloadLen = len - payloadOff;
        if (payloadLen <= 0) return;
        final int fSrcPort = srcPort;
        try {
            DatagramSocket ds = udpSockets.get(srcPort);
            if (ds == null) {
                ds = new DatagramSocket();
                protect(ds);
                udpSockets.put(srcPort, ds);
                final DatagramSocket fDs = ds;
                final int fKeyPort = srcPort;
                new Thread(new Runnable() {
						@Override
						public void run() {
							udpReceiveLoop(fDs, fKeyPort);
						}
					}, "bushuev-udp-" + srcPort).start();
            }
            byte[] payload = new byte[payloadLen];
            System.arraycopy(p, payloadOff, payload, 0, payloadLen);
            ds.send(new DatagramPacket(payload, payloadLen,
									   InetAddress.getByAddress(dstIp), dstPort));
        } catch (Exception e) {
            Log.e(TAG, "udp send", e);
        }
    }

    private void udpReceiveLoop(DatagramSocket ds, int srcPort) {
        byte[] buf = new byte[32767];
        while (running && !ds.isClosed()) {
            try {
                DatagramPacket dp = new DatagramPacket(buf, buf.length);
                ds.receive(dp);
                writeUdpToTun(srcPort, dp.getData(), dp.getLength(),
							  dp.getAddress().getAddress(), dp.getPort());
            } catch (Exception e) {
                break;
            }
        }
    }

    private synchronized void writeUdpToTun(int srcPort, byte[] data, int n,
                                            byte[] dstIp, int dstPort) {
        try {
            byte[] udp = new byte[8 + n];
            udp[0] = (byte) (dstPort >> 8);
            udp[1] = (byte) dstPort;
            udp[2] = (byte) (srcPort >> 8);
            udp[3] = (byte) srcPort;
            udp[4] = (byte) ((n + 8) >> 8);
            udp[5] = (byte) (n + 8);
            System.arraycopy(data, 0, udp, 8, n);

            byte[] ip = new byte[20 + udp.length];
            ip[0] = 0x45;
            ip[2] = (byte) (ip.length >> 8);
            ip[3] = (byte) ip.length;
            ip[8] = 64;
            ip[9] = 17;
            System.arraycopy(dstIp, 0, ip, 12, 4);
            ip[16] = 10; ip[17] = 8; ip[18] = 0; ip[19] = 2;
            System.arraycopy(udp, 0, ip, 20, udp.length);
            writeIp(ip);
        } catch (Exception e) {
            Log.e(TAG, "writeUdpToTun", e);
        }
    }

    private synchronized void writeIp(byte[] ip) {
        try {
            out.write(ip);
            out.flush();
        } catch (Exception e) {
            Log.e(TAG, "writeIp", e);
        }
    }

    private void socks5Connect(Socket s, byte[] dstIp, int dstPort) throws Exception {
        OutputStream os = s.getOutputStream();
        InputStream is = s.getInputStream();
        os.write(new byte[]{0x05, 0x01, 0x00});
        os.flush();
        byte[] resp = new byte[2];
        readFully(is, resp, 2);
        if (resp[0] != 0x05 || resp[1] != 0x00) throw new Exception("socks5 auth");

        byte[] req = new byte[10];
        req[0] = 0x05;
        req[1] = 0x01;
        req[2] = 0x00;
        req[3] = 0x01;
        System.arraycopy(dstIp, 0, req, 4, 4);
        req[8] = (byte) (dstPort >> 8);
        req[9] = (byte) dstPort;
        os.write(req);
        os.flush();

        byte[] head = new byte[4];
        readFully(is, head, 4);
        if (head[1] != 0x00) throw new Exception("socks5 connect code " + head[1]);
        int addrLen;
        if (head[3] == 0x01) addrLen = 4;
        else if (head[3] == 0x03) {
            int l = is.read();
            addrLen = 1 + l;
        } else addrLen = 16;
        byte[] tail = new byte[addrLen + 2];
        readFully(is, tail, tail.length);
    }

    private static void readFully(InputStream is, byte[] buf, int len) throws Exception {
        int off = 0;
        while (off < len) {
            int n = is.read(buf, off, len - off);
            if (n <= 0) throw new Exception("eof");
            off += n;
        }
    }

    private static String ipToString(byte[] ip) {
        return (ip[0] & 0xFF) + "." + (ip[1] & 0xFF) + "." +
			(ip[2] & 0xFF) + "." + (ip[3] & 0xFF);
    }

    private static byte[] ipFromString(String s) {
        String[] p = s.split("\\.");
        return new byte[]{
			(byte) Integer.parseInt(p[0]),
			(byte) Integer.parseInt(p[1]),
			(byte) Integer.parseInt(p[2]),
			(byte) Integer.parseInt(p[3])
        };
    }

    private void stopVpn() {
        running = false;
        if (reader != null) {
            reader.interrupt();
            reader = null;
        }
        for (Socket s : tcpSockets.values()) {
            try { s.close(); } catch (Exception ignored) {}
        }
        tcpSockets.clear();
        for (DatagramSocket d : udpSockets.values()) {
            try { d.close(); } catch (Exception ignored) {}
        }
        udpSockets.clear();
        if (out != null) {
            try { out.close(); } catch (Exception ignored) {}
            out = null;
        }
        if (vpnInterface != null) {
            try { vpnInterface.close(); } catch (Exception ignored) {}
            vpnInterface = null;
        }
        stopForeground(true);
        stopSelf();
    }

    private Notification buildNotification() {
        NotificationManager nm =
			(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
				CHANNEL_ID, "Bushuev VPN", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
			this, 0, open,
			Build.VERSION.SDK_INT >= 23
			? PendingIntent.FLAG_IMMUTABLE : 0);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
			? new Notification.Builder(this, CHANNEL_ID)
			: new Notification.Builder(this);
        return b.setContentTitle("BushuevVPNFREE")
			.setContentText("Туннель активен через " + proxyHost + ":" + proxyPort)
			.setSmallIcon(android.R.drawable.ic_dialog_info)
			.setContentIntent(pi)
			.setOngoing(true)
			.build();
    }

    @Override
    public void onRevoke() {
        stopVpn();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }
}
