package com.bushuev.vpn1;
import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_VPN = 1001;
    private EditText etHost, etPort;
    private Button btnToggle;
    private TextView tvStatus;
    private boolean connected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etHost = (EditText) findViewById(R.id.etHost);
        etPort = (EditText) findViewById(R.id.etPort);
        btnToggle = (Button) findViewById(R.id.btnToggle);
        tvStatus = (TextView) findViewById(R.id.tvStatus);
        etHost.setText("127.0.0.1");
        etPort.setText("1080");

        btnToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (connected) {
                    Intent i = new Intent(MainActivity.this, BushuevVpnService.class);
                    i.setAction(BushuevVpnService.ACTION_DISCONNECT);
                    startService(i);
                    setConnected(false);
                    return;
                }
                String host = etHost.getText().toString().trim();
                String portStr = etPort.getText().toString().trim();
                if (host.isEmpty() || portStr.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Укажи host и port", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent prepare = VpnService.prepare(MainActivity.this);
                if (prepare != null) {
                    startActivityForResult(prepare, REQ_VPN);
                } else {
                    onActivityResult(REQ_VPN, RESULT_OK, null);
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_VPN) return;
        if (resultCode != RESULT_OK) {
            Toast.makeText(this, "Нет разрешения VPN", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, BushuevVpnService.class);
        i.setAction(BushuevVpnService.ACTION_CONNECT);
        i.putExtra(BushuevVpnService.EXTRA_HOST, etHost.getText().toString().trim());
        i.putExtra(BushuevVpnService.EXTRA_PORT, Integer.parseInt(etPort.getText().toString().trim()));
        startService(i);
        setConnected(true);
    }

    private void setConnected(boolean value) {
        connected = value;
        btnToggle.setText(value ? "Отключить" : "Подключить");
        tvStatus.setText(value ? "Статус: подключено" : "Статус: отключено");
        etHost.setEnabled(!value);
        etPort.setEnabled(!value);
    }
}
